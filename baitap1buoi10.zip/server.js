import express from "express";

const app = express();
app.use(express.json());

app.get("/api", (req, res) => {
  res.send("API is running");
});

const PORT = 3069;
app.listen(PORT, () => {
  console.log(`Server running on port http://localhost:${PORT}`);
});
